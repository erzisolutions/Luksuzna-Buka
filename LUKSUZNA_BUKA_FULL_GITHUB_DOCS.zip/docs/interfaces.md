# 🖥️ Interfejsi

LUKSUZNA BUKA podržava više interfejsa:

- Streamlit GUI
- CLI meni
- REST API
- Web dashboard
- VR/AR moduli (eksperimentalno)