# ⚙️ Konfiguracija

Konfiguracije se nalaze u `config/` folderu.

- `compliance.yaml`: LUFS i true peak po platformi
- `genre_templates.yaml`: Preseti EQ/kompresije po žanru