# 🔌 REST API

## Endpointi

### /upload
POST audio fajla za procesiranje.

### /transcribe
POST fajla za transkripciju i vraća JSON rezultat.

### /master
POST audio za automatski mastering.

Dokumentacija dostupna i kao `openapi.yaml`