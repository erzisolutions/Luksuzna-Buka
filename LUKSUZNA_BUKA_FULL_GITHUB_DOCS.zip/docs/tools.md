# 🛠️ Preporučeni alati i dataseti

| Alat       | Opis                             |
|------------|----------------------------------|
| Matchering | Open-source mastering            |
| Spleeter   | Izolacija vokala/instrumenata    |
| Demucs     | Source separation (Facebook AI)  |
| Librosa    | Analiza spektrograma, LUFS       |
| AudioCraft | Meta AI za generativni zvuk      |
| CommonVoice| Dataset za govor i transkripciju |