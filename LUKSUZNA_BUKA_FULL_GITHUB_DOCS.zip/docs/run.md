# ⚙️ Pokretanje

## GUI

```bash
streamlit run gui.py
```

## REST API

```bash
python api_server.py
```

## CLI Meni

```bash
python launcher.py
```

## Web Interfejs

Otvorite lokalni fajl `webapp/web_interface.html` u pretraživaču.