# 🗣️ BCS Transkripcija

Whisper model treniran za BCS jezike sa podrškom za:

- Detekciju dijalekta
- Sentiment analizu
- Speaker diarization

Output: .json i .txt transkripti po govorniku