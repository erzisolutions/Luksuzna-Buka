# 🎚️ Mastering Workflow

Ova ruta koristi limiter, EQ, kompresiju i QA scoring za profesionalan mastering izlaz.

- Ulaz: .wav, .mp3
- Izlaz: .wav + QA report
- QA Score: mora biti 10/10