# 🧰 Instalacija

Instaliraj luksuznu buku pomoću pip-a:

```bash
pip install luksuzna-buka
```

Za razvojnu verziju:

```bash
git clone https://github.com/erzi-ai/luksuzna-buka.git
cd luksuzna-buka
pip install -r requirements.txt
```