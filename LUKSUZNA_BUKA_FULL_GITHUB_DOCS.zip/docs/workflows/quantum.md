# 🧬 Quantum Workflow

Eksperimentalni workflow koji koristi Qiskit za generaciju kvantno modifikovanog signala.

- Koristi kvantna stanja za modifikaciju amplituda
- Output: .wav + hash + audit log