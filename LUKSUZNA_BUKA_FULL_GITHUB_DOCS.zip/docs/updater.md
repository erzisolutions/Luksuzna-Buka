# 🔄 Auto-Update Sistem

Pokreni:

```bash
python utils/updater.py
```

Funkcionalnosti:

- Preuzima novu verziju ZIP-a
- Pravi backup stare verzije
- Automatski restart aplikacije