# 🎙️ Podcast Workflow

Mastering govora uz automatsko podešavanje LUFS-a, transkripciju i speaker diarization.

- Ciljani LUFS: -16.0
- Output: .mp3 + transkript + JSON report