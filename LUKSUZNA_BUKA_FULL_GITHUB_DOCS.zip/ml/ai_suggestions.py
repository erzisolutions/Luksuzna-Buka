# Suggest processing based on genre and input
